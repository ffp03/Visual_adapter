'use strict';
// Milestone 8 (2026-11-22): run the 5 large dev sites (dev-07, dev-09..12) x P4-on/P4-off on the
// user's laptop, which has its own ~/.env.shared (no key is copied anywhere). Cross-platform, no docker.
//   node laptop-run.cjs install <extracted-transfer-dir>   verify hashes, archive what it replaces, copy in
//   node laptop-run.cjs check                              read-only readiness checks, no API calls
//   node laptop-run.cjs run                                check, then one node process per site
//   node laptop-run.cjs pack                               stage changed files + log into a results tarball
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),{spawn,execFileSync}=require('node:child_process');
const ROOT=path.resolve(__dirname,'../../../..'),HERE=__dirname;
const RUN7=path.join(ROOT,'workspace/revision/dev-runs/capability/2026-11-21T07-04-41-280Z');
const SITES=['dev-07','dev-09','dev-10','dev-11','dev-12'],POLICIES=['P4-on','P4-off'];
const START=path.join(HERE,'laptop-start.json'),LOG=path.join(HERE,'laptop-run.log'),OUT=path.join(ROOT,'workspace/m8-laptop-out');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const log=s=>{const line=new Date().toISOString()+' '+s;console.log(line);fs.appendFileSync(LOG,line+'\n');};
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>{const p=path.join(d,e.name);return e.isDirectory()?walk(p):e.isFile()?[p]:[];});
const rel=p=>path.relative(ROOT,p).split(path.sep).join('/');

function install(dir){
 dir=path.resolve(dir);const sums=fs.readFileSync(path.join(dir,'SHA256SUMS'),'utf8').trim().split('\n').map(l=>l.match(/^([0-9a-f]{64})  (.+)$/));
 const archive=path.join(ROOT,'workspace/archive/2026-11-22-m8-laptop-pre');let copied=0,archived=0,same=0;
 for(const [,h,file] of sums){const src=path.join(dir,...file.split('/'));if(sha(fs.readFileSync(src))!==h)throw Error('transfer-hash '+file);}
 for(const [,h,file] of sums){
  const src=path.join(dir,...file.split('/')),dst=path.join(ROOT,...file.split('/'));
  if(fs.existsSync(dst)){if(sha(fs.readFileSync(dst))===h){same++;continue;}
   const a=path.join(archive,...file.split('/'));fs.mkdirSync(path.dirname(a),{recursive:true});fs.copyFileSync(dst,a);archived++;}
  fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst);copied++;
 }
 fs.mkdirSync(path.join(ROOT,'workspace/revision/results/capability-agent-8-1795375429159'),{recursive:true});
 console.log(JSON.stringify({installed:copied,alreadyIdentical:same,archivedBeforeReplacing:archived,archive:archived?rel(archive):null}));
}

function check(){
 const problems=[],info={};
 info.node=process.version;if(Number(process.version.slice(1).split('.')[0])<22)problems.push('node-older-than-22');
 info.totalGB=+(os.totalmem()/2**30).toFixed(1);info.freeGB=+(os.freemem()/2**30).toFixed(1);if(os.freemem()<7*2**30)problems.push('under-7GB-free-memory');
 try{const k=require(path.join(ROOT,'backend/deepseek-runner.cjs')).sharedKey();info.keyLoaded=k.length>20;}catch(e){problems.push('no-deepseek-key: '+e.message);}
 const context=JSON.parse(fs.readFileSync(path.join(RUN7,'context-m8.json'),'utf8')),state=JSON.parse(fs.readFileSync(path.join(RUN7,'iteration-8/iteration.json'),'utf8'));
 const local=p=>{const x=['C:\\Dev\\Visual_adapter\\','/home/randy/Dev/Visual_adapter/'].find(q=>p.startsWith(q));return x?path.join(ROOT,...p.slice(x.length).split(/[\\/]/)):p;};
 let pages=0;for(const s of context.sites.filter(s=>SITES.includes(s.id)))for(const p of s.pages){const f=local(p.file);
  if(!fs.existsSync(f)){problems.push('missing-page '+rel(f));continue;}if(p.sha256&&sha(fs.readFileSync(f))!==p.sha256)problems.push('page-hash '+rel(f));pages++;}
 info.pagesChecked=pages;
 if(sha(fs.readFileSync(path.join(ROOT,'extension/procedure-v3.js')))!==state.gateHash)problems.push('gate-hash-differs-from-iteration-8');
 if(!fs.existsSync(path.join(ROOT,'workspace/revision/corpus/dev-manifest.json')))problems.push('missing dev-manifest.json');
 if(fs.existsSync(path.join(RUN7,'STOP.json')))problems.push('STOP.json present in run folder');
 try{require(path.join(ROOT,'tests/revision/eval/dom.cjs')).createDOM('<p>x</p>',{url:'https://example.org/'}).window.close();}catch(e){problems.push('dom-unavailable: '+e.message);}
 try{const {Ledger}=require(path.join(ROOT,'backend/agent/ledger.cjs'));info.ledger=new Ledger({maxDevRequests:900}).totals();}catch(e){problems.push('ledger: '+e.message);}
 return {ok:!problems.length,problems,info};
}

function runOne(policy,site,deadline){
 return new Promise(resolve=>{
  const t=Date.now(),args=['--max-old-space-size=6144',path.join(HERE,'rerun.cjs'),policy,'--iteration=8','--sites='+site,'--deadline='+deadline];
  const child=spawn(process.execPath,args,{cwd:ROOT,env:{...process.env,REVISION_BASELINE_CACHE:path.join(ROOT,'workspace/revision/dev-runs/run7/baseline-cache')}});
  const full=fs.createWriteStream(path.join(HERE,`laptop-${policy}-${site}.log`));let minFree=os.freemem();
  const mem=setInterval(()=>{minFree=Math.min(minFree,os.freemem());},5000);
  const onData=b=>{full.write(b);for(const l of b.toString().split('\n'))if(/"event":"(admission|output|policy-error)"|Error/.test(l))log('  '+l.slice(0,220));};
  child.stdout.on('data',onData);child.stderr.on('data',onData);
  child.on('close',code=>{clearInterval(mem);full.end();log(`${policy} ${site} exit ${code} ${((Date.now()-t)/1000).toFixed(1)}s minFreeGB ${(minFree/2**30).toFixed(1)}`);resolve(code);});
 });
}

async function run(){
 const c=check();log('check '+JSON.stringify(c));if(!c.ok){process.exitCode=2;return;}
 const deadline=new Date(Date.now()+3*3600e3).toISOString();
 if(!fs.existsSync(START))fs.writeFileSync(START,JSON.stringify({startedAt:Date.now(),deadline,host:os.hostname()}));
 for(const policy of POLICIES)for(const site of SITES){
  await runOne(policy,site,deadline);
  if(fs.existsSync(path.join(RUN7,'STOP.json'))){log('STOP '+fs.readFileSync(path.join(RUN7,'STOP.json'),'utf8'));process.exitCode=5;return;}
 }
 log('all site-runs finished; next: node laptop-run.cjs pack');
}

function pack(){
 const start=JSON.parse(fs.readFileSync(START,'utf8')).startedAt-2000,stage=path.join(OUT,'stage');
 if(fs.existsSync(stage))throw Error('stage exists already: '+rel(stage));
 const files=walk(path.join(ROOT,'workspace/revision')).filter(f=>fs.statSync(f).mtimeMs>=start);
 const archived=path.join(ROOT,'workspace/archive/2026-11-22-m8-laptop-pre');if(fs.existsSync(archived))files.push(...walk(archived));
 const sums=[];for(const f of files){const d=path.join(stage,...rel(f).split('/'));fs.mkdirSync(path.dirname(d),{recursive:true});fs.copyFileSync(f,d);sums.push(sha(fs.readFileSync(f))+'  '+rel(f));}
 fs.writeFileSync(path.join(stage,'SHA256SUMS'),sums.join('\n')+'\n');
 const tarball=path.join(OUT,'m8-laptop-results.tar.gz');
 execFileSync('tar',['-czf',tarball,'-C',stage,'.'],{stdio:'inherit'});
 console.log(JSON.stringify({files:files.length,tarball:rel(tarball),bytes:fs.statSync(tarball).size,sha256:sha(fs.readFileSync(tarball))}));
}

const [mode,arg]=process.argv.slice(2);
if(mode==='install')install(arg);
else if(mode==='check'){const c=check();console.log(JSON.stringify(c,null,1));if(!c.ok)process.exitCode=2;}
else if(mode==='run')run().catch(e=>{log('ERROR '+e.stack);process.exitCode=1;});
else if(mode==='pack')pack();
else{console.error('usage: install <dir> | check | run | pack');process.exitCode=1;}
