'use strict';
// Milestone 8 (2026-11-22): fresh development re-run of P4-on and P4-off with the bug fixes
// (DeepSeek thinking cap, gate clutter marking), on run 7's 12 sites with run 7's exact prompt
// (b838e299...). Only the code changed. Usage: node rerun.cjs prepare | P4-on [--limit=N] | P4-off [--limit=N]
const fs=require('node:fs'),path=require('node:path');
const ROOT=path.resolve(__dirname,'../../../..');
const cap=require(path.join(ROOT,'backend/agent/capability-run.cjs'));
const {SYSTEM_PROMPT}=require(path.join(ROOT,'backend/agent/loop.cjs')),{hash}=require(path.join(ROOT,'backend/agent/ledger.cjs'));
const RUN7=path.join(ROOT,'workspace/revision/dev-runs/capability/2026-11-21T07-04-41-280Z');
const CONTEXT=path.join(RUN7,'context-m8.json'),INDEX=Number(process.argv.find(a=>a.startsWith('--iteration='))?.slice(12))||6;
// Iteration 6 crashed (heap out of memory, policyRun keeps every site's DOMs) during dev-07 p5;
// iteration 7 (same prompt and code) holds dev-07..dev-12, one process per site.
// Paths in the saved context/state may be from the Windows laptop or from claude-host; map either to ROOT.
const PREFIXES=['C:\\Dev\\Visual_adapter\\','/home/randy/Dev/Visual_adapter/'];
const local=p=>{if(typeof p!=='string')return p;const x=PREFIXES.find(q=>p.startsWith(q));return x?path.join(ROOT,...p.slice(x.length).split(/[\\/]/)):p;};
const fix=v=>Array.isArray(v)?v.map(fix):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,fix(x)])):local(v);
(async()=>{
 const phase=process.argv[2];
 if(phase==='prepare-next'){
  const context=JSON.parse(fs.readFileSync(CONTEXT,'utf8')),prompt=fs.readFileSync(path.join(RUN7,'iteration-4/prompt.txt'),'utf8');
  const state=cap.iteration(context,INDEX,prompt.slice(SYSTEM_PROMPT.length+1));
  if(state.promptHash!==hash(prompt))throw Error('prompt-hash');console.log(JSON.stringify({iteration:state.folder,output:state.output}));return;
 }
 if(phase==='prepare'){
  const old=JSON.parse(fs.readFileSync(path.join(RUN7,'context-final.json'),'utf8'));
  const context={...fix(old),deadline:new Date(Date.now()+4*3600e3).toISOString(),tuningDevCap:900,
   m8:{reason:'milestone 8 bug-fix re-run; prompt identical to iteration 4 (run 7 final)',from:'context-final.json',at:new Date().toISOString()}};
  for(const s of context.sites)for(const p of s.pages)if(!fs.existsSync(p.file))throw Error('missing '+p.file);
  fs.writeFileSync(CONTEXT,JSON.stringify(context,null,2),{flag:'wx'});
  const prompt=fs.readFileSync(path.join(RUN7,'iteration-4/prompt.txt'),'utf8');
  if(!prompt.startsWith(SYSTEM_PROMPT+'\n'))throw Error('prompt-prefix');
  const state=cap.iteration(context,INDEX,prompt.slice(SYSTEM_PROMPT.length+1));
  if(state.promptHash!==hash(prompt)||!state.promptHash.startsWith('b838e299'))throw Error('prompt-hash '+state.promptHash);
  console.log(JSON.stringify({context:CONTEXT,iteration:state.folder,output:state.output,promptHash:state.promptHash,gateHash:state.gateHash}));
  return;
 }
 if(!['P4-on','P4-off'].includes(phase))throw Error('usage: prepare | P4-on | P4-off');
 const context=fix(JSON.parse(fs.readFileSync(CONTEXT,'utf8')));
 // The lab run (iteration 8) may start after the 4 h deadline set at preparation.
 const late=process.argv.find(a=>a.startsWith('--deadline='))?.slice(11);if(late)context.deadline=new Date(late).toISOString();
 const only=process.argv.find(a=>a.startsWith('--sites='))?.slice(8).split(',');
 if(only)context.sites=context.sites.filter(x=>only.includes(x.id));
 else if(INDEX===7)context.sites=context.sites.filter(x=>x.id>='dev-07');
 const state=fix(JSON.parse(fs.readFileSync(path.join(RUN7,'iteration-'+INDEX,'iteration.json'),'utf8')));
 const limit=Number(process.argv.find(a=>a.startsWith('--limit='))?.slice(8))||Infinity;
 await cap.policyRun(context,state,phase,{maxSites:limit});
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
